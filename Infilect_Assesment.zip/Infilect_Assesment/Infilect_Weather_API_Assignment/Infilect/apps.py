from django.apps import AppConfig


class InfilectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Infilect'
